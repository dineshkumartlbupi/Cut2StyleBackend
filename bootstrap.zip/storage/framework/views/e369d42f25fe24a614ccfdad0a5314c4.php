

<h2>Welcome Customer!</h2>
<form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit">Logout</button>
</form>

<?php /**PATH C:\xampp\htdocs\Cut2StyleBackend\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>