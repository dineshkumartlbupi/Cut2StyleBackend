<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <h3 class="mb-4"><i class="fas fa-edit text-primary me-2"></i>Edit User</h3>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST" class="shadow p-4 rounded bg-white">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name" class="form-label"><strong>Name</strong></label>
            <input type="text" class="form-control" id="name" name="name"
                   value="<?php echo e(old('name', $user->name)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label"><strong>Email</strong></label>
            <input type="email" class="form-control" id="email" name="email"
                   value="<?php echo e(old('email', $user->email)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="role" class="form-label"><strong>Role</strong></label>
            <select class="form-select" name="role" id="role" required>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role); ?>" <?php echo e($user->role === $role ? 'selected' : ''); ?>><?php echo e($role); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="gender" class="form-label"><strong>Gender</strong></label>
            <select class="form-select" name="gender" id="gender">
                <option value="">Select Gender</option>
                <option value="Male" <?php echo e(old('gender', $user->gender) == 'Male' ? 'selected' : ''); ?>>Male</option>
                <option value="Female" <?php echo e(old('gender', $user->gender) == 'Female' ? 'selected' : ''); ?>>Female</option>
                <option value="Other" <?php echo e(old('gender', $user->gender) == 'Other' ? 'selected' : ''); ?>>Other</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="dob" class="form-label"><strong>Date of Birth</strong></label>
            <input type="date" class="form-control" id="dob" name="dob"
                   value="<?php echo e(old('dob', $user->dob ? $user->dob->format('Y-m-d') : '')); ?>">
        </div>

        <div class="mb-3">
            <label for="address" class="form-label"><strong>Address</strong></label>
            <textarea class="form-control" id="address" name="address" rows="3"><?php echo e(old('address', $user->address)); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="password" class="form-label"><strong>New Password</strong> (optional)</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Leave blank to keep current password">
        </div>

        <div class="mb-3">
            <label for="password_confirmation" class="form-label"><strong>Confirm Password</strong></label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation">
        </div>

        <div class="d-flex justify-content-between">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Back
            </a>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save me-1"></i> Update User
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cut2StyleBackend\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>