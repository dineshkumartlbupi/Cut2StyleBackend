<h2>Welcome Vendor!</h2>
<form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit">Logout</button>
</form>

<?php echo $__env->make('layouts.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cut2StyleBackend\resources\views/vendor/dashboard.blade.php ENDPATH**/ ?>