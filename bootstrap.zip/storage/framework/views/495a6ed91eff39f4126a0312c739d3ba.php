<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <h3 class="mb-4">
        <i class="fas fa-eye text-primary me-2"></i> Vendor Details
    </h3>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($vendor->name); ?></h5>
            <p><strong>Email:</strong> <?php echo e($vendor->email); ?></p>
            <p><strong>Gender:</strong> <?php echo e($vendor->gender); ?></p>
            <p><strong>Date of Birth:</strong> <?php echo e(\Carbon\Carbon::parse($vendor->dob)->format('d-m-Y')); ?></p>
            <p><strong>Address:</strong> <?php echo e($vendor->address ?? 'No address provided'); ?></p>
        </div>
    </div>

    <a href="<?php echo e(route('admin.vendors.index')); ?>" class="btn btn-primary mt-3">
        <i class="fas fa-arrow-left me-2"></i> Back to List
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cut2StyleBackend\resources\views/admin/vendors/show.blade.php ENDPATH**/ ?>