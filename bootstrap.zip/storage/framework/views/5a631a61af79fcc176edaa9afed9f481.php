<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>User Details</h1>

        <div class="card">
            <div class="card-header">
                <h3><?php echo e($user->name); ?></h3>
            </div>
            <div class="card-body">
                <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                <p><strong>Role:</strong> <?php echo e(ucfirst($user->role)); ?></p>
                <p><strong>Created At:</strong> <?php echo e($user->created_at->format('d M Y')); ?></p>
                <p><strong>Last Updated:</strong> <?php echo e($user->updated_at->format('d M Y')); ?></p>
            </div>
        </div>

        <div class="mt-3">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary">Back to User List</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cut2StyleBackend\resources\views/admin/users/show.blade.php ENDPATH**/ ?>