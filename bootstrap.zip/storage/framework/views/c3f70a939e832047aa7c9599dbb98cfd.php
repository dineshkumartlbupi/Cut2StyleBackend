<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0 text-dark fw-bold">
            <i class="fas fa-users text-primary me-2"></i> Vendors List
        </h3>
        <a href="<?php echo e(route('admin.vendors.create')); ?>" class="btn btn-success shadow-sm">
            <i class="fas fa-plus me-1"></i> Add Vendor
        </a>
    </div>

    <?php if($vendors->count()): ?>
        <div class="table-responsive shadow rounded overflow-hidden border">
            <table class="table table-hover align-middle mb-0 table-bordered table-striped">
                <thead class="table-primary text-center">
                    <tr>
                        <th style="width: 5%;">#</th>
                        <th><i class="fas fa-user me-1"></i> Name</th>
                        <th><i class="fas fa-envelope me-1"></i> Email</th>
                        <th><i class="fas fa-venus-mars me-1"></i> Gender</th>
                        <th><i class="fas fa-map-marker-alt me-1"></i> Location</th>
                        <th style="width: 20%;"><i class="fas fa-cogs me-1"></i> Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center align-middle">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class="text-start fw-semibold"><?php echo e($vendor->name); ?></td>
                            <td><?php echo e($vendor->email); ?></td>
                            <td><?php echo e($vendor->gender ?? 'N/A'); ?></td>
                            <td><?php echo e($vendor->address ?? 'N/A'); ?></td>
                            <td>
                                <div class="d-flex justify-content-center gap-2">
                                    <a href="<?php echo e(route('admin.vendors.show', $vendor->id)); ?>" class="btn btn-sm btn-outline-info" title="View" data-bs-toggle="tooltip" data-bs-placement="top">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.vendors.edit', $vendor->id)); ?>" class="btn btn-sm btn-outline-warning" title="Edit" data-bs-toggle="tooltip" data-bs-placement="top">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.vendors.destroy', $vendor->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this vendor?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete" data-bs-toggle="tooltip" data-bs-placement="top">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="text-center mt-5">
            <img src="https://cdn-icons-png.flaticon.com/512/3176/3176363.png" alt="No vendors" width="150" class="mb-3 animate__animated animate__fadeInDown">
            <h5 class="text-muted">
                <i class="fas fa-user-slash me-2"></i>No vendors available
            </h5>
            <p class="text-secondary">You can start by adding a new vendor.</p>
            <a href="<?php echo e(route('admin.vendors.create')); ?>" class="btn btn-outline-primary mt-3">
                <i class="fas fa-plus me-1"></i> Add Vendor
            </a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cut2StyleBackend\resources\views/admin/vendors/index.blade.php ENDPATH**/ ?>