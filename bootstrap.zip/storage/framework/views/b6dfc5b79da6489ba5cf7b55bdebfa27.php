<nav class="navbar navbar-expand-lg navbar-light  shadow-sm py-3">

    <div class="container-fluid">
        <!-- Logo Above the Navbar -->
        <div class="d-flex justify-content-center mb-3">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Cut2Style Logo" class="img-fluid" style="max-height: 50px;">
        </div>

        <!-- Brand Name -->
        <a class="navbar-brand fw-bold fs-4 text-warning text-center" href="<?php echo e(route('admin.dashboard')); ?>">
            
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link text-dark <?php echo e(request()->routeIs('admin.dashboard') ? 'active fw-semibold' : ''); ?>"
                       href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="fas fa-home me-1"></i> Dashboard
                    </a>
                </li>

                    <a class="nav-link text-danger"
                       href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </li>
            </ul>
        </div>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\Cut2StyleBackend\resources\views/partials/admin-navbar.blade.php ENDPATH**/ ?>