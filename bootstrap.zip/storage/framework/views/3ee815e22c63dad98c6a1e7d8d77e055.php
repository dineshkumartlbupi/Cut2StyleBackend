<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Edit Product</h3>
    <form action="<?php echo e(route('admin.products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Price (₹)</label>
            <input type="number" name="price" value="<?php echo e($product->price); ?>" class="form-control" required step="0.01">
        </div>
        <div class="mb-3">
            <label>Current Image</label><br>
            <?php if($product->image_url): ?>
                <img src="<?php echo e(asset('storage/' . $product->image_url)); ?>" alt="" width="100" class="mb-2">
            <?php endif; ?>
            <input type="file" name="image" class="form-control">
        </div>
        <button class="btn btn-success">Update Product</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cut2StyleBackend\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>